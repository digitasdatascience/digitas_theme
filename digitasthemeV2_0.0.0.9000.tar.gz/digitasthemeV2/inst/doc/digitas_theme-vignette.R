## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ------------------------------------------------------------------------
library(sysfonts)
library(extrafont)
library(ggplot2)

## ----setup---------------------------------------------------------------
library(digitasthemeV2)

## ------------------------------------------------------------------------
options(warn=-1)
library(digitasthemeV2)
#Without theme
ggplot(iris, aes(Sepal.Width, Sepal.Length, color = Species)) +  geom_point(size = 4) 
#With theme
data("iris")
d1 <- qplot(x  = Sepal.Length, y =Sepal.Width,colour = Species,data = iris,geom = "point")
d1 + theme_digitas() + 
  scale_color_digitas(theme="red") + 
  labs(title="Digitas theme")
d1 + theme_digitas() + 
  scale_color_digitas(theme="green") + 
  labs(title="Digitas theme")
d1 + theme_digitas() + 
  scale_color_digitas(theme="blue") + 
  labs(title="Digitas theme")



## ------------------------------------------------------------------------
library("gapminder")
library("tidyr")
library("dplyr")

stacked_df <- gapminder %>% 
  filter(year == 2007) %>%
  mutate(lifeExpGrouped = cut(lifeExp, 
                              breaks = c(0, 50, 65, 80, 90),
                              labels = c("Under 50", "50-65", "65-80", "80+"))) %>%
  group_by(continent, lifeExpGrouped) %>%
  summarise(continentPop = sum(as.numeric(pop)))

#set order of stacks by changing factor levels
stacked_df$lifeExpGrouped = factor(stacked_df$lifeExpGrouped, levels = rev(levels(stacked_df$lifeExpGrouped)))

## ------------------------------------------------------------------------
#create plot
ggplot(data = stacked_df, 
                       aes(x = continent,
                           y = continentPop,
                           fill = lifeExpGrouped)) +
  geom_bar(stat = "identity", 
           position = "fill") +
  theme_digitas() +
  scale_y_continuous(labels = scales::percent) +
  scale_fill_digitas(theme="red") +
  geom_hline(yintercept = 0, size = 1, colour = "#333333") +
  labs(title = "How life expectancy varies",
       subtitle = "% of population by life expectancy band, 2007") +
  theme(legend.position = "top", 
        legend.justification = "left") +
  guides(fill = guide_legend(reverse = TRUE))
ggplot(data = stacked_df, 
                       aes(x = continent,
                           y = continentPop,
                           fill = lifeExpGrouped)) +
  geom_bar(stat = "identity", 
           position = "fill") +
  theme_digitas() +
  scale_y_continuous(labels = scales::percent) +
  scale_fill_digitas(theme="green") +
  geom_hline(yintercept = 0, size = 1, colour = "#333333") +
  labs(title = "How life expectancy varies",
       subtitle = "% of population by life expectancy band, 2007") +
  theme(legend.position = "top", 
        legend.justification = "left") +
  guides(fill = guide_legend(reverse = TRUE))
stacked_bars<-ggplot(data = stacked_df, 
                       aes(x = continent,
                           y = continentPop,
                           fill = lifeExpGrouped)) +
  geom_bar(stat = "identity", 
           position = "fill") +
  theme_digitas() +
  scale_y_continuous(labels = scales::percent) +
  scale_fill_digitas(theme="blue") +
  geom_hline(yintercept = 0, size = 1, colour = "#333333") +
  labs(title = "How life expectancy varies",
       subtitle = "% of population by life expectancy band, 2007") +
  theme(legend.position = "top", 
        legend.justification = "left") +
  guides(fill = guide_legend(reverse = TRUE))
stacked_bars
ggplot(data = stacked_df, 
                       aes(x = continent,
                           y = continentPop,
                           fill = lifeExpGrouped)) +
  geom_bar(stat = "identity", 
           position = "fill") +
  theme_digitas() +
  scale_y_continuous(labels = scales::percent) +
  scale_fill_digitas(theme="black") +
  geom_hline(yintercept = 0, size = 1, colour = "#333333") +
  labs(title = "How life expectancy varies",
       subtitle = "% of population by life expectancy band, 2007") +
  theme(legend.position = "top", 
        legend.justification = "left") +
  guides(fill = guide_legend(reverse = TRUE))




## ------------------------------------------------------------------------
finalise_plot(plot_name = stacked_bars,
              source = "Source: Digitas",
              save_filepath = "plot.png",
              width_pixels = 640,
              height_pixels = 550
              
              )

