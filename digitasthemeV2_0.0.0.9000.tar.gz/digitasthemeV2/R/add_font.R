#' Add gotham rounded -
#'
#'
#' @keywords add_font

#' @export
add_font<-function(){
  options(warn=-1)
  extrafont::loadfonts(device = "win")
  sysfonts::font_add(family = "Gotham Rounded Digitas", regular = 'GothamRounded-Book.otf')
}
