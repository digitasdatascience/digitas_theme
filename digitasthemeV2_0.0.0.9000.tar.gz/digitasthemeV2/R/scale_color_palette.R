
#' Add color palette to the digitas theme
#'
#'
#' @keywords scale_color_digitas

#' @export

scale_color_digitas <- function(theme="airbnb", tech_key = list(
  red = c("#AC1D23","#EC2329", "#F04A24","#F37721","#F9A314","#FFD10A"),
  green = c("#A6AC27", "#7C9C37","#508945","#659D66","#7AB185","#A2D5EE"),
  blue = c("#89B0C8","#7288A4","#696BA1","#624DA1","#82467B","#A24053"),
  black = c("#272727","#B6B4B3","#ECECEC","#FFFFFF")

)) {

  scale_color_manual(values=tech_key[[theme]])

}
