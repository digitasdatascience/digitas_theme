#' Add digitas theme to ggplot chart
#'
#' This function allows you to add the digitas theme to your ggplot graphics.
#' @keywords digitas_style
#' @export
#' @examples
#'A <- data.frame(x = 1:4, y = 1:4, z = c('A','A','B','B'))
#'clr<-color_palette_digitas()
#'ggplot2::ggplot(A) +
#'  geom_point(aes(x = x, y = y)) +
#'  facet_wrap(~z) +
#'  theme_bw()+
#'  theme_digitas(clr$red$dark_red)+
#'  theme(strip.text = element_text(colour = 'white'))



#GGplot theme

theme_digitas <- function(){
  options(warn=-1)
  theme(
    #Set title
    plot.title = ggplot2::element_text(family='Futura-Medium',
                                       #size=20,
                                       #face='bold',
                                       color="#222222"),
    plot.subtitle = ggplot2::element_text(family= 'GothamRounded-Book',
                                          #face='italic',
                                          #size=16,
                                          margin=ggplot2::margin(4,0,4,0)),
    legend.position = "bottom",
    legend.text.align = 0,
    legend.background = ggplot2::element_blank(),
    legend.title = ggplot2::element_blank(),
    legend.key = ggplot2::element_blank(),
    legend.text = ggplot2::element_text(family='GothamRounded-Book',
                                        #size=12,
                                        color="#222222"),

    axis.title = ggplot2::element_blank(),
    axis.text = ggplot2::element_text(family='GothamRounded-Book',
                                      #size=10,
                                      color="#222222"),
    #axis.text.x = ggplot2::element_text(margin=ggplot2::margin(5, b = 10)),
    axis.ticks = ggplot2::element_line(color="gray"),
    axis.line = ggplot2::element_line(color="gray"),

    panel.grid.minor = ggplot2::element_blank(),
    panel.grid.major.y = ggplot2::element_line(linetype = 2, color="#cbcbcb"),
    panel.grid.major.x = ggplot2::element_blank(),

    panel.background = ggplot2::element_blank(),

    strip.background = ggplot2::element_rect(fill="white")
    #strip.text = ggplot2::element_text(size  = 22,  hjust = 0)

  )
}

