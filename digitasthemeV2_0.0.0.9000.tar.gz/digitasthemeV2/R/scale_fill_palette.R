#' Add color palette to the digitas theme
#'
#'
#' @keywords scale_fill_digitas

#' @export

scale_fill_digitas<- function(theme="red", tech_key = list(
  red = c("#AC1D23","#EC2329", "#F04A24","#F37721","#F9A314","#FFD10A","#F29D35","#D86704","#8C3A0B","#3F1F0C"),
  green = c("#A6AC27", "#7C9C37","#508945","#659D66","#7AB185","#03A56A","#028C65","#015949","#02725E","#A2D5EE","#01343F"),
  blue = c("#89B0C8","#7288A4","#696BA1","#405672","#9BC0F2","#B3CEF2","#89A6BF","#89A6BF","#624DA1","#82467B","#A24053"),
  black = c("#272727","#B6B4B3","#ECECEC","#FFFFFF","#5C6872","#59413B","#8C7671","#59444C"),
  red_green  = c("#AC1D23","#EC2329", "#F04A24","#F37721","#F9A314","#FFD10A","#A6AC27", "#7C9C37","#508945","#659D66","#7AB185","#A2D5EE"),
  red_blue =c("#AC1D23","#EC2329", "#F04A24","#F37721","#F9A314","#FFD10A","#89B0C8","#7288A4","#696BA1","#624DA1","#82467B","#A24053"),
  red_black = c("#AC1D23","#EC2329", "#F04A24","#F37721","#F9A314","#FFD10A","#272727","#B6B4B3","#ECECEC","#FFFFFF"),
  red_green_blue_black  =c("#AC1D23","#EC2329", "#F04A24","#F37721","#F9A314","#FFD10A",
                           "#A6AC27", "#7C9C37","#508945","#659D66","#7AB185","#A2D5EE",
                           "#89B0C8","#7288A4","#696BA1","#624DA1","#82467B","#A24053",
                           "#272727","#B6B4B3","#ECECEC","#FFFFFF")

)) {

  scale_fill_manual(values=tech_key[[theme]])

}
