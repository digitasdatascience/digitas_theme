library(testthat)
library(digitasthemeV2)
library(ggplot2)
data("iris")

test_that("ggplot is plotting the chart", {
d1 <- qplot(x  = Sepal.Length, y =Sepal.Width,colour = Species,data = iris,geom = "point")
expect_is(d1 + theme_digitas() +
            scale_color_digitas(theme="red") +
            labs(title="Airbnb theme",
                 subtitle="now with subtitles for ggplot2 >= 2.1.0"),"ggplot")
})
