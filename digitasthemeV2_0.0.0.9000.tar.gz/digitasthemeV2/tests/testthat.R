library(testthat)
library(digitasthemeV2)

test_check("digitasthemeV2")
